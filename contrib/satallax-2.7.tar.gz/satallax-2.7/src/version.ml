let print_version () = print_string "Satallax Version 2.7"
